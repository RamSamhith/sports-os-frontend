import * as React from 'react';
import { cn } from '@/lib/utils/cn';

export type InputProps = React.InputHTMLAttributes<HTMLInputElement>;

const Input = React.forwardRef<HTMLInputElement, InputProps>(({ className, type, ...props }, ref) => {
  return (
    <input
      type={type}
      className={cn(
        'border-input bg-background/60 placeholder:text-muted-foreground focus-visible:ring-ring/40',
        'flex h-10 w-full rounded-md border px-3 py-2 text-sm',
        'transition-[background-color,border-color,box-shadow,color] duration-[var(--duration-fast)]',
        'hover:border-foreground/30',
        'file:border-0 file:bg-transparent file:text-sm file:font-medium',
        'focus-visible:ring-2 focus-visible:outline-none',
        'disabled:cursor-not-allowed disabled:opacity-50',
        className,
      )}
      ref={ref}
      {...props}
    />
  );
});
Input.displayName = 'Input';

export { Input };
