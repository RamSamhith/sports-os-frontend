type LogLevel = 'debug' | 'info' | 'warn' | 'error';

interface LogPayload {
  level: LogLevel;
  message: string;
  route?: string;
  requestId?: string;
  userId?: string;
  meta?: Record<string, unknown>;
  ts: string;
}

function emit(level: LogLevel, message: string, meta?: Record<string, unknown>) {
  if (typeof window === 'undefined') {
    // Server: structured JSON to stdout
    const payload: LogPayload = {
      level,
      message,
      meta,
      ts: new Date().toISOString(),
    };
    // eslint-disable-next-line no-console
    console[level === 'debug' ? 'log' : level](JSON.stringify(payload));
    return;
  }
  // Client: send to reporter in real implementation; here we just console
  // eslint-disable-next-line no-console
  console[level === 'debug' ? 'log' : level](`[${level}] ${message}`, meta ?? {});
}

export const logger = {
  debug: (msg: string, meta?: Record<string, unknown>) => emit('debug', msg, meta),
  info: (msg: string, meta?: Record<string, unknown>) => emit('info', msg, meta),
  warn: (msg: string, meta?: Record<string, unknown>) => emit('warn', msg, meta),
  error: (msg: string, meta?: Record<string, unknown>) => emit('error', msg, meta),
};
